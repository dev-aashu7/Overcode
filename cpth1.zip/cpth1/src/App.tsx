import React, { useState } from 'react';
import './App.css';
import { StepId, PreAuthFormData, SubmissionReceipt } from './types';
import { MOCK_POLICIES } from './data/mockPolicies';
import { Navbar } from './components/Navbar';
import { HelpModal } from './components/HelpModal';
import { WorkflowSidebar } from './components/WorkflowSidebar';
import { StepHome } from './components/StepHome';
import { StepSearch } from './components/StepSearch';
import { StepDetails } from './components/StepDetails';
import { StepPreAuthForm } from './components/StepPreAuthForm';
import { StepDocUpload } from './components/StepDocUpload';

import { StepReview } from './components/StepReview';
import { StepSuccess } from './components/StepSuccess';

const initialFormData: PreAuthFormData = {
  hospital_name: 'Apollo Care Superspecialty Hospital',
  hospital_id: 'ROHINI-HOSP-7489',
  doctor_name: 'Dr. Rajesh K. Mehta',
  admission_type: 'Planned Admission',
  diagnosis: 'Acute Cholecystitis / ICD-10 K81.0',
  procedure: 'Laparoscopic Cholecystectomy',
  admission_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  stay_days: 3,
  room_category: 'Semi-Private',
  estimated_cost: 85000,
  document_attached: false,
  document_name: null,
};

export const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<StepId>('HOME');
  const [selectedPolicyId, setSelectedPolicyId] = useState<string | null>(null);
  const [formData, setFormData] = useState<PreAuthFormData>(initialFormData);
  const [receipt, setReceipt] = useState<SubmissionReceipt | null>(null);

  const [isHelpOpen, setIsHelpOpen] = useState(false);

  const selectedPolicy = selectedPolicyId ? MOCK_POLICIES[selectedPolicyId] || null : null;
  const hasActivePolicy = Boolean(selectedPolicy && selectedPolicy.policy_status === 'Active');

  const handleSelectPolicy = (policyId: string) => {
    setSelectedPolicyId(policyId);
    setCurrentStep('DETAILS');
  };

  const handleUpdateFormData = (updated: Partial<PreAuthFormData>) => {
    setFormData((prev) => ({ ...prev, ...updated }));
  };

  const handleSubmitPreAuth = () => {
    if (!selectedPolicy) return;

    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const refId = `PA-2026-${randomNum}`;
    const timestamp = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    const newReceipt: SubmissionReceipt = {
      reference_id: refId,
      submitted_at: timestamp,
      policy_id: selectedPolicy.policy_id,
      patient_name: selectedPolicy.patient_name,
      hospital: formData.hospital_name,
      diagnosis: formData.diagnosis,
      estimated_cost: formData.estimated_cost,
      status: 'In Review - TPA Desk',
      sla: '45 Minutes Initial Response Time',
    };

    setReceipt(newReceipt);
    setCurrentStep('SUCCESS');
  };

  const handleStartNewRequest = () => {
    setSelectedPolicyId(null);
    setReceipt(null);
    setFormData(initialFormData);
    setCurrentStep('SEARCH');
  };

  const handleReset = () => {
    setSelectedPolicyId(null);
    setReceipt(null);
    setFormData(initialFormData);
    setCurrentStep('HOME');
  };

  return (
    <div className="app-layout">
      {/* Top Corporate Navigation */}
      <Navbar
        currentStep={currentStep}
        onNavigate={(step) => setCurrentStep(step)}
        onOpenHelp={() => setIsHelpOpen(true)}
        hasActivePolicy={hasActivePolicy}
      />

      <main className="main-container">
        {/* Brand Hero Banner */}
        <div className="brand-hero">
          <div>
            <h1>ApexCare Health TPA</h1>
            <p>Official Hospital Cashless Pre-Authorization Gateway &bull; MedVerify Sandbox</p>
          </div>
          <div className="status-indicator">
            <span>🟢</span>
            <span>TPA Desk Online</span>
          </div>
        </div>

        {/* Content Layout: Left Sidebar + Right Main Step Workspace */}
        <div className="content-grid">
          <WorkflowSidebar
            currentStep={currentStep}
            onNavigate={(step) => setCurrentStep(step)}
            onSelectPolicy={handleSelectPolicy}
            onReset={handleReset}
          />

          <section className="step-workspace" aria-label="Step Workspace">
            {currentStep === 'HOME' && (
              <StepHome onStartSearch={() => setCurrentStep('SEARCH')} />
            )}

            {currentStep === 'SEARCH' && (
              <StepSearch
                initialPolicyId={selectedPolicyId}
                onSelectPolicy={handleSelectPolicy}
              />
            )}

            {currentStep === 'DETAILS' && (
              <StepDetails
                policy={selectedPolicy}
                onBack={() => setCurrentStep('SEARCH')}
                onInitiatePreAuth={() => setCurrentStep('PREAUTH_FORM')}
              />
            )}

            {currentStep === 'PREAUTH_FORM' && (
              <StepPreAuthForm
                policy={selectedPolicy}
                formData={formData}
                onBack={() => setCurrentStep('DETAILS')}
                onNext={(updated) => {
                  handleUpdateFormData(updated);
                  setCurrentStep('DOC_UPLOAD');
                }}
              />
            )}

            {currentStep === 'DOC_UPLOAD' && (
              <StepDocUpload
                formData={formData}
                onBack={() => setCurrentStep('PREAUTH_FORM')}
                onNext={(updated) => {
                  handleUpdateFormData(updated);
                  setCurrentStep('REVIEW');
                }}
              />
            )}

            {currentStep === 'REVIEW' && (
              <StepReview
                policy={selectedPolicy}
                formData={formData}
                onBack={() => setCurrentStep('PREAUTH_FORM')}
                onSubmit={handleSubmitPreAuth}
              />
            )}

            {currentStep === 'SUCCESS' && (
              <StepSuccess
                receipt={receipt}
                onStartNew={handleStartNewRequest}
              />
            )}
          </section>
        </div>
      </main>

      {/* Help Modal */}
      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />
    </div>
  );
};

export default App;
