import React, { useState } from 'react';

interface StepCaptchaProps {
  onBack: () => void;
  onVerify: () => void;
}

export const StepCaptcha: React.FC<StepCaptchaProps> = ({ onBack, onVerify }) => {
  const [isChecked, setIsChecked] = useState<boolean>(false);

  const handleVerify = () => {
    if (isChecked) {
      onVerify();
    }
  };

  return (
    <div className="main-card">
      <h2 className="card-title" id="heading-security-verification">
        Security Verification
      </h2>
      <p className="card-subtitle">
        Please complete the verification before continuing.
      </p>

      {/* Checkpoint Security Advisory */}
      <div className="alert-box alert-info" style={{ marginBottom: '1.5rem' }}>
        <span>🛡️</span>
        <div>
          <strong>Checkpoint:</strong> Automated bot prevention security checkpoint.
          Please complete the human verification below before proceeding to the pre-authorization review.
        </div>
      </div>

      {/* Dedicated Demo CAPTCHA Widget Container */}
      <div className="captcha-container" id="captcha-checkpoint-section">
        <div className="captcha-card" id="demo-captcha-widget" data-testid="demo-captcha-widget">
          <label className="captcha-checkbox-wrap" htmlFor="captcha-checkbox">
            <input
              type="checkbox"
              id="captcha-checkbox"
              name="demo_captcha"
              data-testid="captcha-checkbox"
              className="captcha-checkbox"
              checked={isChecked}
              onChange={(e) => setIsChecked(e.target.checked)}
            />
            <span className="captcha-label" id="captcha-checkbox-label">
              I&apos;m not a robot
            </span>
          </label>

          <div className="captcha-badge" aria-hidden="true">
            <span className="captcha-logo-icon">🤖</span>
            <span className="captcha-badge-text">Demo CAPTCHA</span>
            <span className="captcha-badge-sub">Security Check</span>
          </div>
        </div>

        {/* Dynamic Verification Status Feedback */}
        <div style={{ marginTop: '1.25rem', minHeight: '24px' }}>
          {isChecked ? (
            <span
              id="captcha-status-success"
              data-testid="captcha-status-success"
              style={{
                color: '#15803D',
                fontWeight: 600,
                fontSize: '0.9rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.4rem',
              }}
            >
              <span>✓</span> Verification complete. You may now continue.
            </span>
          ) : (
            <span
              id="captcha-status-pending"
              data-testid="captcha-status-pending"
              style={{ color: '#64748B', fontSize: '0.85rem' }}
            >
              Human verification required. Please check the box above.
            </span>
          )}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="button-bar">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={onBack}
          id="btn-captcha-back"
          data-testid="btn-captcha-back"
        >
          ⬅️ Back to Documents
        </button>

        <button
          type="button"
          className={`btn ${isChecked ? 'btn-primary' : 'btn-disabled'}`}
          disabled={!isChecked}
          onClick={handleVerify}
          id="btn-verify-continue"
          data-testid="btn-verify-continue"
          aria-label="Verify & Continue"
        >
          Verify &amp; Continue
        </button>
      </div>
    </div>
  );
};
