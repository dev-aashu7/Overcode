import React from 'react';
import { SubmissionReceipt } from '../types';

interface StepSuccessProps {
  receipt: SubmissionReceipt | null;
  onStartNew: () => void;
}

export const StepSuccess: React.FC<StepSuccessProps> = ({
  receipt,
  onStartNew,
}) => {
  if (!receipt) {
    return (
      <div className="main-card">
        <p>No submission record found.</p>
        <button
          type="button"
          className="btn btn-primary"
          onClick={onStartNew}
          id="btn-start-new-fallback"
        >
          Start New Request
        </button>
      </div>
    );
  }

  return (
    <div>
      {/* Success Hero Card */}
      <div className="success-card">
        <div className="success-icon">🎉</div>
        <h2 className="success-title" id="success-heading" data-testid="success-heading">
          Pre-Authorization Submitted Successfully
        </h2>
        <p style={{ color: '#475569', fontSize: '1rem', maxWidth: '600px', margin: '0 auto' }}>
          Your cashless authorization dossier has been securely transmitted to the TPA Claims Adjudication Desk.
        </p>

        <div
          className="ref-number-badge"
          id="ref-number-badge"
          data-testid="ref-number-badge"
        >
          {receipt.reference_id}
        </div>

        <p style={{ fontSize: '0.875rem', color: '#64748B' }}>
          Pre-Authorization Reference ID: <strong>{receipt.reference_id}</strong>
        </p>
      </div>

      {/* Structured Submission Details */}
      <div className="main-card">
        <h3 className="card-title">📄 Submission Summary &amp; Tracking Record</h3>

        <div className="sidebar-card" style={{ marginBottom: '1.5rem' }}>
          <table className="key-value-table">
            <tbody>
              <tr>
                <td className="label-col">Submission Status:</td>
                <td className="value-col" id="receipt-status" data-testid="receipt-status">
                  <span className="badge badge-active">{receipt.status}</span>
                </td>
              </tr>
              <tr>
                <td className="label-col">Patient Name:</td>
                <td className="value-col" id="receipt-patient-name" data-testid="receipt-patient-name">
                  <strong>{receipt.patient_name}</strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Policy ID:</td>
                <td className="value-col" id="receipt-policy-id" data-testid="receipt-policy-id">
                  <strong>{receipt.policy_id}</strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Estimated Cost:</td>
                <td className="value-col" id="receipt-estimated-cost" data-testid="receipt-estimated-cost">
                  <strong style={{ color: 'var(--primary-blue)', fontSize: '1.05rem' }}>
                    ₹{receipt.estimated_cost?.toLocaleString()}
                  </strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Submission Date/Time:</td>
                <td className="value-col" id="receipt-submission-time" data-testid="receipt-submission-time">
                  {receipt.submitted_at}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Action Button: Start New Request */}
        <div style={{ textAlign: 'center', marginTop: '1.5rem' }}>
          <button
            type="button"
            className="btn btn-primary"
            onClick={onStartNew}
            id="btn-start-new-request"
            data-testid="btn-start-new-request"
            aria-label="Start New Request"
            style={{ fontSize: '1rem', padding: '0.75rem 2rem' }}
          >
            Start New Request
          </button>
        </div>
      </div>
    </div>
  );
};
