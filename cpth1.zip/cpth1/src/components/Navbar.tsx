import React from 'react';
import { StepId } from '../types';

interface NavbarProps {
  currentStep: StepId;
  onNavigate: (step: StepId) => void;
  onOpenHelp: () => void;
  hasActivePolicy: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentStep,
  onNavigate,
  onOpenHelp,
  hasActivePolicy,
}) => {
  return (
    <header className="top-navbar" role="banner">
      <div className="top-navbar-inner">
        <div
          className="brand-section"
          onClick={() => onNavigate('HOME')}
          id="btn-brand-home"
          data-testid="btn-brand-home"
          role="button"
          tabIndex={0}
        >
          <span className="brand-icon">🏥</span>
          <div>
            <span className="brand-text">ApexCare</span>
            <span className="brand-badge">INSURANCE & TPA</span>
          </div>
        </div>

        <nav className="nav-links" aria-label="Main Navigation">
          <button
            className={`nav-btn ${currentStep === 'HOME' ? 'active' : ''}`}
            onClick={() => onNavigate('HOME')}
            id="btn-nav-home"
            data-testid="btn-nav-home"
          >
            <span>🏠</span>
            <span>Home</span>
          </button>

          <button
            className={`nav-btn ${currentStep === 'SEARCH' ? 'active' : ''}`}
            onClick={() => onNavigate('SEARCH')}
            id="btn-nav-search"
            data-testid="btn-nav-search"
          >
            <span>🔍</span>
            <span>Policy Search</span>
          </button>

          <button
            className={`nav-btn ${
              ['DETAILS', 'PREAUTH_FORM', 'DOC_UPLOAD', 'CAPTCHA', 'REVIEW', 'SUCCESS'].includes(currentStep)
                ? 'active'
                : ''
            }`}
            onClick={() => {
              if (hasActivePolicy) {
                onNavigate('PREAUTH_FORM');
              } else {
                onNavigate('SEARCH');
              }
            }}
            id="btn-nav-preauth"
            data-testid="btn-nav-preauth"
          >
            <span>📝</span>
            <span>Pre-Authorization</span>
          </button>

          <button
            className="nav-btn nav-btn-help"
            onClick={onOpenHelp}
            id="btn-nav-help"
            data-testid="btn-nav-help"
          >
            <span>❓</span>
            <span>Help</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
