import React from 'react';
import { Policy, PreAuthFormData } from '../types';

interface StepReviewProps {
  policy: Policy | null;
  formData: PreAuthFormData;
  onBack: () => void;
  onSubmit: () => void;
}

export const StepReview: React.FC<StepReviewProps> = ({
  policy,
  formData,
  onBack,
  onSubmit,
}) => {
  return (
    <div className="main-card">
      <h2 className="card-title" id="heading-review-verify">
        Review &amp; Verify
      </h2>
      <p className="card-subtitle">
        Please review the collected pre-authorization and clinical information below before final submission.
      </p>

      {/* Read-Only Summary Details */}
      <div className="data-grid-2">
        <div className="sidebar-card">
          <div className="sidebar-card-title">
            <span>👤</span>
            <span>Policy &amp; Patient Information</span>
          </div>
          <table className="key-value-table">
            <tbody>
              <tr>
                <td className="label-col">Policy ID:</td>
                <td className="value-col" id="review-policy-id" data-testid="review-policy-id">
                  <strong>{policy?.policy_id}</strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Patient Name:</td>
                <td className="value-col" id="review-patient-name" data-testid="review-patient-name">
                  <strong>{policy?.patient_name}</strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Policy Status:</td>
                <td className="value-col" id="review-policy-status" data-testid="review-policy-status">
                  <span
                    className={`badge ${
                      policy?.policy_status === 'Active' ? 'badge-active' : 'badge-lapsed'
                    }`}
                  >
                    {policy?.policy_status}
                  </span>
                </td>
              </tr>
              <tr>
                <td className="label-col">Room Category:</td>
                <td className="value-col" id="review-room-category" data-testid="review-room-category">
                  {formData.room_category}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="sidebar-card">
          <div className="sidebar-card-title">
            <span>🏥</span>
            <span>Hospital &amp; Clinical Information</span>
          </div>
          <table className="key-value-table">
            <tbody>
              <tr>
                <td className="label-col">Hospital Name:</td>
                <td className="value-col" id="review-hospital-name" data-testid="review-hospital-name">
                  {formData.hospital_name}
                </td>
              </tr>
              <tr>
                <td className="label-col">Treating Doctor:</td>
                <td className="value-col" id="review-doctor-name" data-testid="review-doctor-name">
                  {formData.doctor_name}
                </td>
              </tr>
              <tr>
                <td className="label-col">Diagnosis / ICD Code:</td>
                <td className="value-col" id="review-diagnosis" data-testid="review-diagnosis">
                  <strong>{formData.diagnosis}</strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Proposed Admission Date:</td>
                <td className="value-col" id="review-admission-date" data-testid="review-admission-date">
                  {formData.admission_date}
                </td>
              </tr>
              <tr>
                <td className="label-col">Estimated Cost:</td>
                <td className="value-col" id="review-estimated-cost" data-testid="review-estimated-cost">
                  <strong style={{ color: 'var(--primary-blue)', fontSize: '1.05rem' }}>
                    ₹{formData.estimated_cost?.toLocaleString()}
                  </strong>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Uploaded Document Name Section */}
      <div className="sidebar-card" style={{ marginBottom: '1.5rem' }}>
        <div className="sidebar-card-title">
          <span>📎</span>
          <span>Uploaded Clinical Document</span>
        </div>
        <table className="key-value-table">
          <tbody>
            <tr>
              <td className="label-col" style={{ width: '30%' }}>
                Uploaded document name:
              </td>
              <td
                className="value-col"
                id="review-document-name"
                data-testid="review-document-name"
              >
                <code style={{ fontSize: '0.95rem' }}>
                  {formData.document_name || 'sample_clinical_document.pdf'}
                </code>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Action Buttons */}
      <div className="button-bar">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={onBack}
          id="btn-review-edit"
          data-testid="btn-review-edit"
          aria-label="Edit"
        >
          Edit
        </button>

        <button
          type="button"
          className="btn btn-primary"
          onClick={onSubmit}
          id="btn-submit-preauth"
          data-testid="btn-submit-preauth"
          aria-label="Submit Pre-Authorization"
        >
          Submit Pre-Authorization
        </button>
      </div>
    </div>
  );
};
