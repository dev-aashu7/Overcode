import React, { useState } from 'react';
import { Policy, PreAuthFormData } from '../types';

interface StepPreAuthFormProps {
  policy: Policy | null;
  formData: PreAuthFormData;
  onBack: () => void;
  onNext: (updatedData: Partial<PreAuthFormData>) => void;
}

export const StepPreAuthForm: React.FC<StepPreAuthFormProps> = ({
  policy,
  formData,
  onBack,
  onNext,
}) => {
  const [hospitalName, setHospitalName] = useState(formData.hospital_name || 'Apollo Care Superspecialty Hospital');
  const [doctorName, setDoctorName] = useState(formData.doctor_name || 'Dr. Rajesh K. Mehta');
  const [diagnosis, setDiagnosis] = useState(formData.diagnosis || 'Acute Cholecystitis / ICD-10 K81.0');
  const [admissionDate, setAdmissionDate] = useState(formData.admission_date || new Date().toISOString().split('T')[0]);
  const [estimatedCost, setEstimatedCost] = useState<number | string>(formData.estimated_cost || 85000);
  const [roomCategory, setRoomCategory] = useState(
    ['General', 'Semi-Private', 'Deluxe'].includes(formData.room_category)
      ? formData.room_category
      : 'Semi-Private'
  );
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!hospitalName.trim()) {
      setValidationError('Please enter the Hospital Name.');
      return;
    }
    if (!doctorName.trim()) {
      setValidationError('Please enter the Treating Doctor name.');
      return;
    }
    if (!diagnosis.trim()) {
      setValidationError('Please enter the Provisional Diagnosis / ICD Code.');
      return;
    }
    if (!admissionDate) {
      setValidationError('Please select the Proposed Admission Date.');
      return;
    }
    if (!estimatedCost || Number(estimatedCost) <= 0) {
      setValidationError('Please enter a valid Estimated Cost.');
      return;
    }

    setValidationError(null);
    onNext({
      hospital_name: hospitalName.trim(),
      doctor_name: doctorName.trim(),
      diagnosis: diagnosis.trim(),
      admission_date: admissionDate,
      estimated_cost: Number(estimatedCost),
      room_category: roomCategory,
    });
  };

  return (
    <div className="main-card">
      <h2 className="card-title">📝 Pre-Authorization Form</h2>
      <p className="card-subtitle">
        Patient: <strong>{policy?.patient_name}</strong> &bull; Policy ID: <strong>{policy?.policy_id}</strong> &bull;
        Avail. Balance: <strong>₹{policy?.available_balance.toLocaleString()}</strong>
      </p>

      {validationError && (
        <div className="alert-box alert-danger" id="alert-form-error" data-testid="alert-form-error">
          <span>⚠️</span>
          <span>{validationError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} id="preauth-form" data-testid="preauth-form">
        <div className="form-grid">
          {/* Hospital Name */}
          <div className="form-group">
            <label className="form-label" htmlFor="input-hospital-name">
              Hospital Name
            </label>
            <input
              type="text"
              className="form-input"
              id="input-hospital-name"
              name="hospital_name"
              data-testid="input-hospital-name"
              aria-label="Hospital Name"
              placeholder="Hospital Name"
              value={hospitalName}
              onChange={(e) => setHospitalName(e.target.value)}
              required
            />
          </div>

          {/* Treating Doctor */}
          <div className="form-group">
            <label className="form-label" htmlFor="input-doctor-name">
              Treating Doctor
            </label>
            <input
              type="text"
              className="form-input"
              id="input-doctor-name"
              name="doctor_name"
              data-testid="input-doctor-name"
              aria-label="Treating Doctor"
              placeholder="Treating Doctor"
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
              required
            />
          </div>

          {/* Provisional Diagnosis / ICD Code */}
          <div className="form-group">
            <label className="form-label" htmlFor="input-diagnosis">
              Provisional Diagnosis / ICD Code
            </label>
            <input
              type="text"
              className="form-input"
              id="input-diagnosis"
              name="diagnosis"
              data-testid="input-diagnosis"
              aria-label="Provisional Diagnosis / ICD Code"
              placeholder="Provisional Diagnosis / ICD Code"
              value={diagnosis}
              onChange={(e) => setDiagnosis(e.target.value)}
              required
            />
          </div>

          {/* Proposed Admission Date */}
          <div className="form-group">
            <label className="form-label" htmlFor="input-admission-date">
              Proposed Admission Date
            </label>
            <input
              type="date"
              className="form-input"
              id="input-admission-date"
              name="admission_date"
              data-testid="input-admission-date"
              aria-label="Proposed Admission Date"
              value={admissionDate}
              onChange={(e) => setAdmissionDate(e.target.value)}
              required
            />
          </div>

          {/* Estimated Cost */}
          <div className="form-group">
            <label className="form-label" htmlFor="input-estimated-cost">
              Estimated Cost
            </label>
            <input
              type="number"
              min="1000"
              max="10000000"
              step="1000"
              className="form-input"
              id="input-estimated-cost"
              name="estimated_cost"
              data-testid="input-estimated-cost"
              aria-label="Estimated Cost"
              placeholder="Estimated Cost"
              value={estimatedCost}
              onChange={(e) => setEstimatedCost(e.target.value)}
              required
            />
          </div>

          {/* Room Category (General / Semi-Private / Deluxe) */}
          <div className="form-group">
            <label className="form-label" htmlFor="input-room-category">
              Room Category
            </label>
            <select
              className="form-select"
              id="input-room-category"
              name="room_category"
              data-testid="input-room-category"
              aria-label="Room Category"
              value={roomCategory}
              onChange={(e) => setRoomCategory(e.target.value)}
            >
              <option value="General">General</option>
              <option value="Semi-Private">Semi-Private</option>
              <option value="Deluxe">Deluxe</option>
            </select>
          </div>
        </div>

        <div className="button-bar">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onBack}
            id="btn-form-back"
            data-testid="btn-form-back"
          >
            ⬅️ Back to Policy Details
          </button>

          <button
            type="submit"
            className="btn btn-primary"
            id="btn-to-doc-upload"
            data-testid="btn-to-doc-upload"
            aria-label="Next: Document Upload"
          >
            Next: Document Upload
          </button>
        </div>
      </form>
    </div>
  );
};
