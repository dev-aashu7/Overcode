import React from 'react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div
        className="modal-content"
        onClick={(e) => e.stopPropagation()}
        id="help-modal-content"
        data-testid="help-modal-content"
      >
        <div className="modal-header">
          <h3>🏥 ApexCare TPA Helpdesk & Support</h3>
          <button
            className="modal-close-btn"
            onClick={onClose}
            id="btn-close-help-modal"
            data-testid="btn-close-help-modal"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <div className="modal-body">
          <p style={{ marginBottom: '1rem' }}>
            24/7 dedicated cashless facilitation desk for empanelled hospitals and TPA partners.
          </p>

          <div className="alert-box alert-info" style={{ marginBottom: '1rem' }}>
            <div>
              <strong>📞 Emergency Pre-Auth Helpline:</strong>
              <div><code>1800-273-9227</code> <em>(1800-APEX-CARE)</em></div>
            </div>
          </div>

          <p style={{ marginBottom: '0.5rem' }}>
            <strong>✉️ Claims Support Desk:</strong><br />
            <code>preauth-desk@apexcare-tpa.mock</code>
          </p>

          <p style={{ marginBottom: '1rem' }}>
            <strong>⏱️ Adjudication SLA:</strong><br />
            Initial query/approval decision dispatched within <strong>45 minutes</strong> of complete document receipt.
          </p>

          <hr style={{ borderColor: 'var(--border-color)', margin: '1rem 0' }} />

          <h4 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '0.5rem' }}>
            📋 Pre-Authorization Checklist for Hospital Desks:
          </h4>
          <ol style={{ paddingLeft: '1.25rem', fontSize: '0.875rem' }}>
            <li>Verify patient Policy ID has active coverage status.</li>
            <li>Obtain attending doctor&apos;s clinical prescription with provisional diagnosis.</li>
            <li>Enclose signed hospital estimate slip with requested room category.</li>
          </ol>
        </div>

        <div className="modal-footer">
          <button
            className="btn btn-primary"
            onClick={onClose}
            id="btn-help-modal-understood"
            data-testid="btn-help-modal-understood"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
