import React, { useState } from 'react';

interface StepHomeProps {
  onStartSearch: () => void;
}

export const StepHome: React.FC<StepHomeProps> = ({ onStartSearch }) => {
  const [isChecked, setIsChecked] = useState<boolean>(false);
  const [isVerified, setIsVerified] = useState<boolean>(false);

  const handleVerify = () => {
    if (!isChecked || isVerified) return;
    setIsVerified(true);
    // Send postMessage to opener (TinyFish)
    if (window.opener) {
      window.opener.postMessage({ type: 'TPA_CAPTCHA_VERIFIED' }, '*');
    }
    window.postMessage({ type: 'TPA_CAPTCHA_VERIFIED' }, '*');
    // Auto-advance after a short delay so the user sees the confirmation
    setTimeout(() => {
      onStartSearch();
    }, 1200);
  };

  return (
    <div className="step-home-container">
      <div className="main-card">
        <h2 className="card-title">Welcome to the ApexCare Hospital TPA Portal</h2>
        <p className="card-subtitle">
          This portal enables empanelled hospital desks and authorized agents to verify insurance policies,
          inspect coverage parameters, and submit electronic Pre-Authorization requests for cashless hospitalization.
        </p>

        <div className="data-grid-2">
          <div className="sidebar-card" style={{ backgroundColor: '#F8FAFC' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#1E293B', marginBottom: '0.5rem' }}>
              🚀 Fast-Track Cashless Pre-Authorization
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#475569', marginBottom: '0.75rem' }}>
              Ensure seamless patient admission by submitting pre-authorization requests with complete clinical documentation:
            </p>
            <ul style={{ fontSize: '0.85rem', color: '#334155', paddingLeft: '1.25rem', lineHeight: '1.6' }}>
              <li><strong>Instant Policy Verification:</strong> Validate coverage, sum insured, room-rent capping, and co-pay clauses.</li>
              <li><strong>Deterministic Processing:</strong> Rapid triage for elective and emergency hospitalizations.</li>
              <li><strong>Electronic Audit Trail:</strong> Automated verification reference generation for tracking.</li>
            </ul>
          </div>

          <div className="sidebar-card" style={{ backgroundColor: '#F8FAFC' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#1E293B', marginBottom: '0.5rem' }}>
              ℹ️ Quick Test Policies
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#475569', marginBottom: '0.75rem' }}>
              You can use any of the following mock insurance records for verification testing:
            </p>
            <ul style={{ fontSize: '0.85rem', color: '#334155', paddingLeft: '1.25rem', lineHeight: '1.6' }}>
              <li><strong>POL-100245:</strong> Rahul Sharma (Active, Standard ₹5L)</li>
              <li><strong>POL-205118:</strong> Sunita Verma (Active, Senior ₹10L with 10% Co-Pay)</li>
              <li><strong>POL-309872:</strong> Priya Nair (Active, Corporate GMC ₹7.5L)</li>
              <li><strong>POL-999001:</strong> Vikram Malhotra (Lapsed Policy test)</li>
            </ul>
          </div>
        </div>

        {/* ─── Security Verification (CAPTCHA) ─── */}
        <div
          className="alert-box alert-info"
          style={{ marginTop: '1.5rem', marginBottom: '1rem' }}
        >
          <span>🛡️</span>
          <div>
            <strong>Security Checkpoint:</strong> Automated bot-prevention check.
            Please complete human verification below before accessing the TPA portal.
          </div>
        </div>

        <div className="captcha-container" id="captcha-checkpoint-section">
          <div
            className="captcha-card"
            id="demo-captcha-widget"
            data-testid="demo-captcha-widget"
          >
            <label className="captcha-checkbox-wrap" htmlFor="captcha-checkbox">
              <input
                type="checkbox"
                id="captcha-checkbox"
                name="demo_captcha"
                data-testid="captcha-checkbox"
                className="captcha-checkbox"
                checked={isChecked}
                disabled={isVerified}
                onChange={(e) => {
                  setIsChecked(e.target.checked);
                }}
              />
              <span className="captcha-label" id="captcha-checkbox-label">
                I&apos;m not a robot
              </span>
            </label>

            <div className="captcha-badge" aria-hidden="true">
              <span className="captcha-logo-icon">🤖</span>
              <span className="captcha-badge-text">Demo CAPTCHA</span>
              <span className="captcha-badge-sub">Security Check</span>
            </div>
          </div>

          {/* Verification status */}
          <div style={{ marginTop: '1.25rem', minHeight: '24px' }}>
            {isVerified ? (
              <span
                id="captcha-status-success"
                data-testid="captcha-status-success"
                style={{
                  color: '#15803D',
                  fontWeight: 600,
                  fontSize: '0.9rem',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                }}
              >
                <span>✓</span> Security Verification Completed — proceeding to portal…
              </span>
            ) : isChecked ? (
              <span
                id="captcha-status-pending"
                data-testid="captcha-status-pending"
                style={{ color: '#64748B', fontSize: '0.85rem' }}
              >
                Verification ready. Click <strong>Verify &amp; Enter Portal</strong> to continue.
              </span>
            ) : (
              <span
                id="captcha-status-pending"
                data-testid="captcha-status-pending"
                style={{ color: '#64748B', fontSize: '0.85rem' }}
              >
                Human verification required. Please check the box above.
              </span>
            )}
          </div>
        </div>

        {/* Verify button */}
        <div style={{ marginTop: '1.5rem', textAlign: 'left' }}>
          <button
            type="button"
            className={`btn ${isChecked && !isVerified ? 'btn-primary' : 'btn-disabled'}`}
            disabled={!isChecked || isVerified}
            onClick={handleVerify}
            id="btn-verify-continue"
            data-testid="btn-verify-continue"
            aria-label="Verify & Enter Portal"
            style={{ fontSize: '1rem', padding: '0.75rem 1.75rem' }}
          >
            {isVerified ? '✓ Security Verification Completed' : 'Verify & Enter Portal 🔓'}
          </button>
        </div>
      </div>
    </div>
  );
};
