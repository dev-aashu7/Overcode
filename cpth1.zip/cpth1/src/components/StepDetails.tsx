import React from 'react';
import { Policy } from '../types';

interface StepDetailsProps {
  policy: Policy | null;
  onBack: () => void;
  onInitiatePreAuth: () => void;
}

export const StepDetails: React.FC<StepDetailsProps> = ({
  policy,
  onBack,
  onInitiatePreAuth,
}) => {
  if (!policy) {
    return (
      <div className="main-card">
        <div className="alert-box alert-danger">
          <span>⚠️</span>
          <span>No policy selected. Please search for a policy first.</span>
        </div>
        <button className="btn btn-secondary" onClick={onBack} id="btn-return-search">
          Return to Policy Search
        </button>
      </div>
    );
  }

  const isActive = policy.policy_status === 'Active';

  return (
    <div className="main-card">
      <h2 className="card-title">📄 Step 2: Policy Details & Coverage Verification</h2>
      <p className="card-subtitle">
        Displaying verified TPA record for Policy: <strong>{policy.policy_id}</strong>
      </p>

      {/* Top Status Alert */}
      {isActive ? (
        <div className="alert-box alert-success" id="alert-policy-active" data-testid="alert-policy-active">
          <span>✅</span>
          <div>
            <strong>Policy Status: ACTIVE</strong> &bull; Underwritten by {policy.insurer_name} &bull; Managed by {policy.tpa_name}
          </div>
        </div>
      ) : (
        <div className="alert-box alert-danger" id="alert-policy-lapsed" data-testid="alert-policy-lapsed">
          <span>❌</span>
          <div>
            <strong>Policy Status: LAPSED</strong> &bull; Coverage ceased on {policy.valid_to}. Cashless Pre-Authorization is prohibited.
          </div>
        </div>
      )}

      {/* Two Column Data Cards */}
      <div className="data-grid-2">
        <div className="sidebar-card">
          <div className="sidebar-card-title">
            <span>👤</span>
            <span>Patient & Policyholder Information</span>
          </div>
          <table className="key-value-table">
            <tbody>
              <tr>
                <td className="label-col">Policy ID:</td>
                <td className="value-col"><strong>{policy.policy_id}</strong></td>
              </tr>
              <tr>
                <td className="label-col">Plan Name:</td>
                <td className="value-col">{policy.plan_name}</td>
              </tr>
              <tr>
                <td className="label-col">Policyholder:</td>
                <td className="value-col">{policy.policyholder_name}</td>
              </tr>
              <tr>
                <td className="label-col">Patient Name:</td>
                <td className="value-col"><strong>{policy.patient_name}</strong></td>
              </tr>
              <tr>
                <td className="label-col">Relationship:</td>
                <td className="value-col">
                  {policy.relationship} &bull; {policy.patient_age} Yrs &bull; {policy.patient_gender}
                </td>
              </tr>
              <tr>
                <td className="label-col">Policy Validity:</td>
                <td className="value-col">{policy.valid_from} to {policy.valid_to}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="sidebar-card">
          <div className="sidebar-card-title">
            <span>💰</span>
            <span>Financial Coverage & Limits</span>
          </div>
          <table className="key-value-table">
            <tbody>
              <tr>
                <td className="label-col">Base Sum Insured:</td>
                <td className="value-col">
                  <strong style={{ color: 'var(--primary-blue)' }}>
                    ₹{policy.sum_insured.toLocaleString()}
                  </strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Available Balance:</td>
                <td className="value-col">
                  <strong style={{ color: 'var(--success-green)' }}>
                    ₹{policy.available_balance.toLocaleString()}
                  </strong>
                </td>
              </tr>
              <tr>
                <td className="label-col">Room Rent Limit:</td>
                <td className="value-col">{policy.room_rent_limit}</td>
              </tr>
              <tr>
                <td className="label-col">ICU Charges Limit:</td>
                <td className="value-col">{policy.icu_limit}</td>
              </tr>
              <tr>
                <td className="label-col">Co-Payment Clause:</td>
                <td className="value-col"><strong>{policy.co_pay_percentage}</strong></td>
              </tr>
              <tr>
                <td className="label-col">Cashless Network:</td>
                <td className="value-col">{policy.cashless_eligibility}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ fontSize: '0.875rem', color: '#475569', marginBottom: '1.25rem' }}>
        <strong>Special Underwriting Conditions:</strong> {policy.special_conditions}
      </div>

      <div className="button-bar">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={onBack}
          id="btn-details-back"
          data-testid="btn-details-back"
        >
          ⬅️ Back to Search
        </button>

        {isActive ? (
          <button
            type="button"
            className="btn btn-primary"
            onClick={onInitiatePreAuth}
            id="btn-initiate-preauth"
            data-testid="btn-initiate-preauth"
            aria-label="Initiate Pre-Authorization"
          >
            Initiate Pre-Authorization
          </button>
        ) : (
          <button
            type="button"
            className="btn btn-disabled"
            disabled
            id="btn-disabled-preauth"
            data-testid="btn-disabled-preauth"
          >
            🚫 Cannot Pre-Authorize (Policy Lapsed)
          </button>
        )}
      </div>
    </div>
  );
};
