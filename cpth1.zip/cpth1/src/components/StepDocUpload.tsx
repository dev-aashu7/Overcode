import React, { useState } from 'react';
import { PreAuthFormData } from '../types';

interface StepDocUploadProps {
  formData: PreAuthFormData;
  onBack: () => void;
  onNext: (updatedData: Partial<PreAuthFormData>) => void;
}

export const StepDocUpload: React.FC<StepDocUploadProps> = ({
  formData,
  onBack,
  onNext,
}) => {
  const [docAttached, setDocAttached] = useState<boolean>(formData.document_attached || false);
  const [docName, setDocName] = useState<string | null>(formData.document_name || null);
  const [useSample, setUseSample] = useState<boolean>(
    formData.document_name === 'sample_clinical_document.pdf' || (!formData.document_name && !formData.document_attached)
  );

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setDocAttached(true);
      setDocName(file.name);
      setUseSample(false);
    }
  };

  const handleToggleSample = (checked: boolean) => {
    setUseSample(checked);
    if (checked) {
      setDocAttached(true);
      setDocName('sample_clinical_document.pdf');
    } else {
      setDocAttached(false);
      setDocName(null);
    }
  };

  const handleProceed = () => {
    // If no document is uploaded, proceed using the synthetic sample document
    const finalDocName = docName || 'sample_clinical_document.pdf';
    onNext({
      document_attached: true,
      document_name: finalDocName,
    });
  };

  return (
    <div className="main-card">
      <h2 className="card-title" id="heading-clinical-doc-upload">
        Clinical Document Upload
      </h2>
      <p className="card-subtitle">
        Please upload relevant clinical documentation (Doctor&apos;s prescription, itemized hospital estimate, or diagnostic reports).
      </p>

      {/* File Upload Control */}
      <div className="form-group" style={{ marginBottom: '1.25rem' }}>
        <label className="form-label" htmlFor="input-clinical-file">
          Select Document (PDF, PNG, JPG)
        </label>
        <input
          type="file"
          id="input-clinical-file"
          name="clinical_document"
          data-testid="input-clinical-file"
          className="form-input"
          accept=".pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg"
          onChange={handleFileUpload}
        />
        <span className="form-hint">Accepted formats: PDF, PNG, JPG (Max 15MB)</span>
      </div>

      {/* Show Selected File Name */}
      {docName && (
        <div
          className="alert-box alert-success"
          id="alert-doc-attached"
          data-testid="alert-doc-attached"
          style={{ marginBottom: '1.25rem' }}
        >
          <span>📄</span>
          <div>
            <strong>Selected File:</strong> <span id="selected-file-name">{docName}</span>
          </div>
        </div>
      )}

      {/* Use Sample Document Option */}
      <div
        className="sidebar-card"
        style={{
          backgroundColor: '#F8FAFC',
          marginBottom: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <input
            type="checkbox"
            id="chk-use-sample-doc"
            name="use_sample_document"
            data-testid="chk-use-sample-doc"
            checked={useSample}
            onChange={(e) => handleToggleSample(e.target.checked)}
            style={{ width: '18px', height: '18px', cursor: 'pointer' }}
          />
          <label
            htmlFor="chk-use-sample-doc"
            style={{ fontSize: '0.925rem', color: '#1E293B', fontWeight: 600, cursor: 'pointer' }}
          >
            Use Sample Document
          </label>
        </div>
        <p style={{ fontSize: '0.825rem', color: '#64748B', margin: 0 }}>
          Enables rapid synthetic pre-authorization testing without requiring a local file upload.
        </p>
      </div>

      {/* Navigation Buttons */}
      <div className="button-bar">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={onBack}
          id="btn-doc-back"
          data-testid="btn-doc-back"
        >
          ⬅️ Back to Form
        </button>

        <button
          type="button"
          className="btn btn-primary"
          onClick={handleProceed}
          id="btn-to-review"
          data-testid="btn-to-review"
          aria-label="Proceed to Review"
        >
          Proceed to Review
        </button>
      </div>
    </div>
  );
};
