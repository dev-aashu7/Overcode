import React, { useState } from 'react';
import { MOCK_POLICIES, SAMPLE_POLICY_IDS } from '../data/mockPolicies';

interface StepSearchProps {
  initialPolicyId: string | null;
  onSelectPolicy: (policyId: string) => void;
}

export const StepSearch: React.FC<StepSearchProps> = ({
  initialPolicyId,
  onSelectPolicy,
}) => {
  const [searchInput, setSearchInput] = useState(initialPolicyId || '');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchInput.trim().toUpperCase();

    if (!query) {
      setErrorMsg('Please enter a valid Policy ID to search.');
      return;
    }

    if (query in MOCK_POLICIES) {
      setErrorMsg(null);
      onSelectPolicy(query);
    } else {
      setErrorMsg(
        `Policy ID '${query}' not found in TPA records. Please try POL-100245, POL-205118, POL-309872, or POL-999001.`
      );
    }
  };

  return (
    <div className="main-card">
      <h2 className="card-title">🔍 Step 1: Policy Search & Verification</h2>
      <p className="card-subtitle">
        Enter the patient&apos;s Policy ID or select from quick samples below to fetch verified insurance coverage details.
      </p>

      {errorMsg && (
        <div className="alert-box alert-danger" id="alert-search-error" data-testid="alert-search-error">
          <span>⚠️</span>
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="data-grid-2">
        <div>
          <form onSubmit={handleSearch} id="form-policy-search">
            <div className="form-group">
              <label className="form-label" htmlFor="input-policy-id">
                Policy ID / Member Card Number
              </label>
              <input
                type="text"
                className="form-input"
                id="input-policy-id"
                data-testid="input-policy-id"
                placeholder="e.g. POL-100245"
                value={searchInput}
                onChange={(e) => {
                  setSearchInput(e.target.value);
                  if (errorMsg) setErrorMsg(null);
                }}
                autoFocus
              />
              <span className="form-hint">Type or paste the synthetic Policy ID (case-insensitive)</span>
            </div>

            <button
              type="submit"
              className="btn btn-primary btn-block"
              id="btn-search-policy"
              data-testid="btn-search-policy"
            >
              Search Policy 🔍
            </button>
          </form>
        </div>

        <div className="sidebar-card" style={{ backgroundColor: '#F8FAFC' }}>
          <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#1E293B', marginBottom: '0.5rem' }}>
            Quick Select for Testing
          </h4>
          <p style={{ fontSize: '0.825rem', color: '#64748B', marginBottom: '0.75rem' }}>
            Click a policy button to populate and verify immediately:
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {SAMPLE_POLICY_IDS.map((pid) => {
              const pol = MOCK_POLICIES[pid];
              const isActive = pol.policy_status === 'Active';

              return (
                <button
                  key={pid}
                  type="button"
                  className="btn btn-secondary"
                  style={{
                    justifyContent: 'space-between',
                    fontSize: '0.85rem',
                    padding: '0.5rem 0.75rem',
                  }}
                  onClick={() => onSelectPolicy(pid)}
                  id={`btn-quick-select-${pid}`}
                  data-testid={`btn-quick-select-${pid}`}
                >
                  <span style={{ fontFamily: 'monospace', fontWeight: 700 }}>{pid}</span>
                  <span>{pol.patient_name}</span>
                  <span className={`badge ${isActive ? 'badge-active' : 'badge-lapsed'}`}>
                    {pol.policy_status}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
