import React from 'react';
import { StepId } from '../types';
import { MOCK_POLICIES, SAMPLE_POLICY_IDS } from '../data/mockPolicies';

interface WorkflowSidebarProps {
  currentStep: StepId;
  onNavigate: (step: StepId) => void;
  onSelectPolicy: (policyId: string) => void;
  onReset: () => void;
}

const STEPS: { id: StepId; number: number; label: string }[] = [
  { id: 'HOME', number: 1, label: 'Portal Home (Security Check)' },
  { id: 'SEARCH', number: 2, label: 'Policy Search' },
  { id: 'DETAILS', number: 3, label: 'Policy Details' },
  { id: 'PREAUTH_FORM', number: 4, label: 'Pre-Auth Form' },
  { id: 'DOC_UPLOAD', number: 5, label: 'Document Upload' },
  { id: 'REVIEW', number: 6, label: 'Review & Verify' },
  { id: 'SUCCESS', number: 7, label: 'Submission Receipt' },
];

export const WorkflowSidebar: React.FC<WorkflowSidebarProps> = ({
  currentStep,
  onNavigate,
  onSelectPolicy,
  onReset,
}) => {
  const currentStepIndex = STEPS.findIndex((s) => s.id === currentStep);

  return (
    <aside className="sidebar-panel" aria-label="Workflow Tracker and Sample Policies">
      <div className="sidebar-card">
        <div className="sidebar-card-title">
          <span>📋</span>
          <span>Pre-Auth Workflow</span>
        </div>

        <ul className="step-list">
          {STEPS.map((step, idx) => {
            const isActive = step.id === currentStep;
            const isCompleted = idx < currentStepIndex;

            return (
              <li
                key={step.id}
                className={`step-item ${isActive ? 'active' : ''} ${
                  isCompleted ? 'completed' : ''
                }`}
                onClick={() => {
                  // Allow navigating back to completed steps or current step
                  if (idx <= currentStepIndex || step.id === 'HOME' || step.id === 'SEARCH') {
                    onNavigate(step.id);
                  }
                }}
                id={`step-item-${step.id.toLowerCase()}`}
                data-testid={`step-item-${step.id.toLowerCase()}`}
              >
                <span className="step-icon-num">
                  {isCompleted ? '✓' : step.number}
                </span>
                <span>{step.label}</span>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="sidebar-card">
        <div className="sidebar-card-title">
          <span>🔑</span>
          <span>Sample Policy IDs</span>
        </div>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>
          Click any card to populate and verify immediately:
        </p>

        <div className="policy-chip-list">
          {SAMPLE_POLICY_IDS.map((pid) => {
            const pol = MOCK_POLICIES[pid];
            const isActive = pol.policy_status === 'Active';

            return (
              <button
                key={pid}
                className="policy-chip"
                onClick={() => onSelectPolicy(pid)}
                id={`sidebar-select-policy-${pid}`}
                data-testid={`sidebar-select-policy-${pid}`}
              >
                <div className="policy-chip-header">
                  <span className="policy-chip-id">{pid}</span>
                  <span
                    className={`badge ${isActive ? 'badge-active' : 'badge-lapsed'}`}
                  >
                    {pol.policy_status}
                  </span>
                </div>
                <div className="policy-chip-name">{pol.patient_name}</div>
              </button>
            );
          })}
        </div>

        <div style={{ marginTop: '1rem' }}>
          <button
            className="btn btn-secondary btn-block"
            onClick={onReset}
            id="btn-sidebar-reset"
            data-testid="btn-sidebar-reset"
            style={{ fontSize: '0.85rem', padding: '0.5rem' }}
          >
            🔄 Reset to Home
          </button>
        </div>
      </div>
    </aside>
  );
};
