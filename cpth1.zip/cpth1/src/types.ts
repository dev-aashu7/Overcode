export type StepId = 
  | 'HOME' 
  | 'SEARCH' 
  | 'DETAILS' 
  | 'PREAUTH_FORM' 
  | 'DOC_UPLOAD' 
  | 'CAPTCHA'
  | 'REVIEW' 
  | 'SUCCESS';

export interface Policy {
  policy_id: string;
  insurer_name: string;
  tpa_name: string;
  plan_name: string;
  policy_status: 'Active' | 'Lapsed';
  valid_from: string;
  valid_to: string;
  policyholder_name: string;
  patient_name: string;
  relationship: string;
  patient_age: number;
  patient_gender: 'Male' | 'Female' | 'Other';
  sum_insured: number;
  available_balance: number;
  room_rent_limit: string;
  icu_limit: string;
  co_pay_percentage: string;
  ped_waiting_period: string;
  cashless_eligibility: string;
  special_conditions: string;
}

export interface PreAuthFormData {
  hospital_name: string;
  hospital_id: string;
  doctor_name: string;
  admission_type: 'Planned Admission' | 'Emergency Admission';
  diagnosis: string;
  procedure: string;
  admission_date: string;
  stay_days: number;
  room_category: string;
  estimated_cost: number;
  document_attached: boolean;
  document_name: string | null;
}

export interface SubmissionReceipt {
  reference_id: string;
  submitted_at: string;
  policy_id: string;
  patient_name: string;
  hospital: string;
  diagnosis: string;
  estimated_cost: number;
  status: string;
  sla: string;
}
