# ApexCare Health TPA - Mock Cashless Pre-Authorization Portal

A lightweight, deterministic mock TPA insurance web application built with **React + Vite + TypeScript** for the **MedVerify** project demo. It simulates a hospital TPA cashless helpdesk for browser agents (such as Tinyfish) to test end-to-end policy verification, clinical data entry, document submission, and reference tracking.

---

## 🚀 Running the Portal

### Prerequisites
- Node.js 18+ (tested on Node v22)
- npm 9+

### Start Local Development Server
```bash
npm install
npm run dev
```
Open **[http://localhost:5173](http://localhost:5173)** in your browser.

### Production Build
```bash
npm run build
```

---

## 📋 Core Workflow

The portal follows an explicit 8-step client-side state machine:

1. **Home (`HOME`)**: Portal landing screen with TPA desk status and quick-start button.
2. **Policy Search (`SEARCH`)**: Search by Policy ID or click quick-select sample buttons.
3. **Policy Details (`DETAILS`)**: Verified breakdown of Policy Status (Active/Lapsed), Insured & Patient details, Sum Insured, Available Balance, Room-Rent limits, Co-Pay %, and Cashless network coverage.
4. **Pre-Authorization Form (`PREAUTH_FORM`)**: Structured form for hospital name, provider ID, doctor, diagnosis, procedure, admission date, stay duration, room category, and estimated cost.
5. **Document Upload (`DOC_UPLOAD`)**: Clinical document uploader (`.pdf`, `.png`, `.jpg`) with a one-click synthetic sample document toggle (`sample_clinical_document.pdf`) for browser automation.
6. **Security Verification (`CAPTCHA`)**: Dedicated human verification checkpoint requiring explicit interaction (checking "I'm not a robot" and clicking "Verify & Continue") before proceeding.
7. **Review (`REVIEW`)**: Verification dossier summarizing all parameters with hospital declaration certification checkbox.
8. **Submission Success (`SUCCESS`)**: Confirmation receipt showing a generated Reference Number (e.g., `PA-2026-XXXXXX`), timestamp, tracking status, and 45-minute turnaround SLA.

---

## 🔑 Predefined Synthetic Policies

| Policy ID | Patient Name | Plan / Type | Sum Insured | Co-Pay | Status | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`POL-100245`** | Rahul Sharma | Optima Platinum Individual | ₹5,00,000 | 0% | **Active** | ₹4.2L balance, ₹5k room cap |
| **`POL-205118`** | Sunita Verma | Senior Citizen Comprehensive | ₹10,00,000 | 10% | **Active** | ₹8.5L balance, single AC room |
| **`POL-309872`** | Priya Nair | Corporate GMC Floater | ₹7,50,000 | 0% | **Active** | Full balance, no capping |
| **`POL-999001`** | Vikram Malhotra | Basic Hospitalization | ₹3,00,000 | 20% | **Lapsed** | Pre-auth disabled (tests agent error handling) |

---

## 🤖 Browser Agent Optimization
- **Predictable Element Selectors**: Every button, input, select, and checkbox has clear, unique `id` and `data-testid` attributes (e.g. `id="input-policy-id"`, `id="btn-search-policy"`, `id="btn-initiate-preauth"`, `id="captcha-checkbox"`, `id="btn-verify-continue"`).
- **Zero Latency**: State is managed in-memory with zero backend or database delays.
- **Agent Fallback**: Includes the one-click synthetic document toggle on the upload step so automation agents don't require physical file uploads on disk.
- **Explicit Checkpoint**: The CAPTCHA checkpoint is visible and requires deliberate interaction to simulate human-in-the-loop verification.

---

## 🛠️ Project Structure
```
medverify-mock_website/
├── src/
│   ├── components/
│   │   ├── Navbar.tsx          # Top corporate navigation header
│   │   ├── WorkflowSidebar.tsx # Workflow step tracker & quick policy chips
│   │   ├── HelpModal.tsx       # 24x7 TPA desk help popup
│   │   ├── StepHome.tsx        # Portal landing screen
│   │   ├── StepSearch.tsx      # Policy search screen
│   │   ├── StepDetails.tsx     # Policy verification screen
│   │   ├── StepPreAuthForm.tsx # Hospital pre-auth entry form
│   │   ├── StepDocUpload.tsx   # Document uploader & sample toggle
│   │   ├── StepCaptcha.tsx     # Demo CAPTCHA human checkpoint screen
│   │   ├── StepReview.tsx      # Final review screen
│   │   └── StepSuccess.tsx     # Submission receipt screen
│   ├── data/
│   │   └── mockPolicies.ts     # Predefined synthetic policies
│   ├── types.ts                # TypeScript interfaces
│   ├── App.tsx                 # Main layout & step state coordinator
│   ├── App.css                 # Enterprise healthcare styling
│   ├── index.css               # Base CSS reset
│   └── main.tsx                # React entry mount
├── index.html                  # HTML entry point
├── package.json                # Dependencies (React 19, TypeScript, Vite)
├── tsconfig.json               # TypeScript configuration
├── vite.config.ts              # Vite configuration
└── README.md                   # Documentation
```
